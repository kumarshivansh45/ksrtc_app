//! example user

String userFirstName = "Martin";
String userSurname = "Gogołowicz";
