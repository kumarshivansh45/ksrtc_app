import 'package:bank_ui/model/card_data_model.dart';

//! example cards
List<CardDataModel> cardsData = [
  CardDataModel(
    'PL17114020040000310281356268',
    "02/23",
    'Mastercard',
    5821045678109335,
    '4,855.23',
  ),
  CardDataModel(
    "PL00000000000000000000000000",
    "12/23",
    'Visa',
    2564689060323168,
    '200.00',
  ),
  CardDataModel(
    'PL17114020040000310281356268',
    "01/22",
    'Mastercard',
    7065447803090891,
    '33,200.00',
  ),
];
