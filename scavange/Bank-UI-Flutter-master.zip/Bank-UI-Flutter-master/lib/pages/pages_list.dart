import 'package:bank_ui/pages/cards_page.dart';
import 'package:bank_ui/pages/home_page.dart';

// pages list for bottomBar
final List pages = [
  const HomePage(),
  const CardsPage(),
];
