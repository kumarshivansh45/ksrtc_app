# Flutter Bank UI
A simple bank UI template with a little bit of backend. Created by Martin Gogołowicz.

## How it looks:

https://user-images.githubusercontent.com/81767518/144501671-df07d366-e4f4-4a5e-88fe-bc8ba6ce5bcc.mov



https://user-images.githubusercontent.com/81767518/144501695-502e7d7e-7829-4817-8da3-8a52db506156.mov

