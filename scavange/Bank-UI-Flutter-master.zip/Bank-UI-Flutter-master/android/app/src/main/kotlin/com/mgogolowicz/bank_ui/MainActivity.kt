package com.mgogolowicz.bank_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
